# SimpleDroneControl website
## Made on Vercel & Notion
