# 3D models for SDC
In this repository you can find .stl files of our project's parts, so you can print them assemble it by yourself

### In archive you will only find files, which were used for testing. The latest versions of parts are located directly in the main branch.
